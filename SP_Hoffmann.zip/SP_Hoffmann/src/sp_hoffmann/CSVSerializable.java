package sp_hoffmann;

public interface CSVSerializable {
    String toCSV();
    static CSVSerializable fromCSV(String csv) {
        throw new UnsupportedOperationException("Método fromCSV no implementado.");
    }
}

