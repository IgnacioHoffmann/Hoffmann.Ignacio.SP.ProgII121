package sp_hoffmann;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class Inventario<T extends CSVSerializable & Comparable<T>> {
    private List<T> elementos = new ArrayList<>();

    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    public T obtener(int indice) {
        return elementos.get(indice);
    }

    public void eliminar(int indice) {
        elementos.remove(indice);
    }

    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrados = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                filtrados.add(elemento);
            }
        }
        return filtrados;
    }

    public void ordenar() {
        Collections.sort(elementos);
    }

    public void ordenar(Comparator<T> comparator) {
        elementos.sort(comparator);
    }

    public void paraCadaElemento(Consumer<T> accion) {
        for (T elemento : elementos) {
            accion.accept(elemento);
        }
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        ordenar(); 
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
        oos.writeObject(elementos);
        }
    }


    
    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            elementos = (List<T>) ois.readObject();
        }
    }

    public void guardarEnCSV(String ruta) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(ruta))) {
            for (T elemento : elementos) {
                writer.write(elemento.toCSV());
                writer.newLine();
            }
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> constructor) throws IOException {
        elementos.clear(); 
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                elementos.add(constructor.apply(linea));
            }
        }
    ordenar(); 
  }

}
