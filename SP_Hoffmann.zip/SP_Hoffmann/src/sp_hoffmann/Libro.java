package sp_hoffmann;

import java.io.Serializable;

public class Libro implements CSVSerializable, Comparable<Libro>, Serializable {
    private int id;
    private String titulo;
    private String autor;
    private Categoria categoria;

    public Libro(int id, String titulo, String autor, Categoria categoria) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    @Override
    public int compareTo(Libro otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + autor + "," + categoria;
    }

    public static Libro fromCSV(String csv) {
        String[] partes = csv.split(",");
        int id = Integer.parseInt(partes[0].trim());
        String titulo = partes[1].trim();
        String autor = partes[2].trim();
        Categoria categoria = Categoria.valueOf(partes[3].trim());
        return new Libro(id, titulo, autor, categoria);
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Titulo: " + titulo + ", Autor: " + autor + ", Categoria: " + categoria;
    }
}

