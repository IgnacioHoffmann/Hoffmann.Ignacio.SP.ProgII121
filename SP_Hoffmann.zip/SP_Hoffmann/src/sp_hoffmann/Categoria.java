package sp_hoffmann;

public enum Categoria {
    CIENCIA,
    LITERATURA,
    TECNOLOGIA,
    ARTE,
    HISTORIA,
    ENTRETENIMIENTO
}
